#include<stdio.h>
int main(){
    int n;
    printf("Enter number of rows ");
    scanf("%d",&n);
    int nsp=n-1; //no. of spaces in first line =n-1
    for(int i=1;i<=n ;i++){ //no. of rows
        int a=i-1; 
        for(int q=1;q<=nsp;q++){ //below 4 lines are used to print num of spaces in each row 
            printf(" ");
        }
        nsp--;
        for(int j=1 ;j<=i;j++){
            int d=j+64;
            char ch=(char)d;
            printf("%c",ch);
        }
        for(int k=1;k<=i-1;k++){
            int d=i+64-k;
            char ch=(char)d;
            printf("%c",ch);
            d--;
        }
        printf("\n");
    }
}
