#include<stdio.h>
int main (){
    int n,m;
    printf("Enter no of rows :");
    scanf("%d",&n);
    if (n%2!=0){
        m=(n+1)/2;
    }
    else{
        printf("entered value should be odd num");
        
    }
    for (int i=1 ;i<=n; i++){
        if(i==m){
            printf("*");
        }
        else{
            for (int j =1; j<=n;j++){
            if(j==m){
                printf("*");
            }
            else{
                printf(" ");
                
            }
        }
        }
        
        printf("\n");
    }
}