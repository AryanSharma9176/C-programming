#include <stdio.h>

int main()
{
    int n ;
    printf("enter your number of rows :");
    scanf("%d",&n);
    for (int i=1 ; i<=n ; i++){     //outer loop signify number of rows ..iterator is i 
        printf("\n");
        for (int j=1;j<=n-i+1;j++){     //inner loops is for columns ie how many times in a line ... iterator is j
        printf("*");                
    }
    
    }

    return 0;
}

