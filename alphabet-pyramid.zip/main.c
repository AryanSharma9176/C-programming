#include<stdio.h>
int main(){
    int n;
    printf("Enter number of rows ");
    scanf("%d",&n);
    for (int i=1;i<=n;i++){ //number of rows
        int a=1 ;
        for(int j=1 ; j<=n-i;j++){ //number of spaces in each row
            printf(" ");
            
        }
        for (int k=1 ;k<=2*i-1;k++){ //number of charecters/digits to be printed in each line
            int d=a+64;  //ASCII value of A is 65 
            char ch=(char)d ;   
            printf("%c",ch);
            a++;
        }
        printf("\n");
    }
}