#include <stdio.h>

int main()
{
    int r ;
    printf("enter your number of rows:");
    scanf("%d",&r);
    for (int i=1 ; i<=r ; i++){     //outer loop signify number of rows ..iterator is i 
        printf("\n");
        for (int j=1;j<=i;j++){     //inner loops is for columns ie how many times in a line ... iterator is j
        printf("%d",j);                
    }
    
    }

    return 0;
}

